INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('KRRISH','4500000');
INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('KRRISH2','8500000');
INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('PS1','1200000');
INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('PS2','7800000');
INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('AARYA','3600000');
INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('DESHAMUDURU','9900000');
INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('TAGORE','4500000');
INSERT INTO `movie_library` (`movie_name`, `collection`)
VALUES ('VALTERU VEERIAH','4500000');
